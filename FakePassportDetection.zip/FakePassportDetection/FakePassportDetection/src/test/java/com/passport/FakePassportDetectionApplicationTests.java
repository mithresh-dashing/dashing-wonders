package com.passport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FakePassportDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
