package com.passport.service;

import java.util.Optional;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.passport.data.CriminalRecord;
import com.passport.data.Passenger;
import com.passport.data.Response;
import com.passport.repo.PassengerRepo;
import com.passport.repo.CriminalRecordRepo;

@RestController
public class PassengerService {
	
	@Autowired
	private CriminalRecordRepo criminalRepo;

	@Autowired
	private PassengerRepo repo;

	@GetMapping(path = "/passenger")
	public Response getPassenger(@RequestParam(name = "aadharNo") long aadharNo) {
		Response response = new Response();
		if (aadharNo < 0) {
			response.setMessage("Invalid AadharNo");
			response.setStatus("Failure");
		} else {
			Optional<Passenger> result = repo.findByAadharno(aadharNo);
			if(result.isPresent()) {
				response.setStatus("Success");
				response.setPassenger(result.get());
			} else {
				response.setMessage("No records found.");
				response.setStatus("Failure");
			}
		}
		return response;
	}
	
	@GetMapping(path = "/criminalRecord")
	public Response getCriminalRecord(@RequestParam(name = "aadharNo") long aadharNo) {
		Response response = new Response();
		if (aadharNo < 0) {
			response.setMessage("Invalid AadharNo");
			response.setStatus("Failure");
		} else {
			List<CriminalRecord> result = criminalRepo.findByAadharno(aadharNo);
			if(null != result && !result.isEmpty()) {
				response.setStatus("Success");
				response.setCriminalRecords(result);
			} else {
				response.setMessage("No records found.");
				response.setStatus("Success");
			}
		}
		return response;
	}

}
