package com.passport.data;

import java.util.List;

public class Response {
	private String message;
	private String status;
	private Passenger passenger;
	private List<CriminalRecord> criminalRecords;

	public List<CriminalRecord> getCriminalRecords() {
		return criminalRecords;
	}

	public void setCriminalRecords(List<CriminalRecord> criminalRecords) {
		this.criminalRecords = criminalRecords;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Passenger getPassenger() {
		return passenger;
	}
	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	} 

}
