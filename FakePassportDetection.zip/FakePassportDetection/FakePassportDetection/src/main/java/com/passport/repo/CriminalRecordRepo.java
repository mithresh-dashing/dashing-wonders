package com.passport.repo;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.passport.data.CriminalRecord;

@Repository
public interface CriminalRecordRepo extends PagingAndSortingRepository<CriminalRecord, Integer> {
	List<CriminalRecord> findByAadharno(long aadharNo);
}
