package com.passport.repo;

import java.util.Optional;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.passport.data.Passenger;

@Repository
public interface PassengerRepo extends PagingAndSortingRepository<Passenger, Integer> {
	Optional<Passenger> findByAadharno(long aadharNo);
}
