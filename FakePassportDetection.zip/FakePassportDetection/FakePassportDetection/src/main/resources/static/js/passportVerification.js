function fetchDetails() {
    fetchAadharDetails();
    fetchCriminalRecords();
}

function fetchAadharDetails() {
    var adharNo = document.getElementById("aadharNumber").value;
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            var responseJson = JSON.parse(this.response);
            if (responseJson && responseJson.status
                && responseJson.status == "Success") {
                if (responseJson.passenger) {
                    document.getElementById("aadhar").value = responseJson.passenger.aadharno;
                    document.getElementById("name").value = responseJson.passenger.name;
                    document.getElementById("age").value = responseJson.passenger.age;
                    document.getElementById("gender").value = responseJson.passenger.gender;
                    document.getElementById("phone").value = responseJson.passenger.phno;
                }
            } else {
                if (responseJson && responseJson.status
                    && responseJson.status == "Failure") {
                    document.getElementById("aadhar").value = "";
                    document.getElementById("name").value = "";
                    document.getElementById("age").value = "";
                    document.getElementById("gender").value = "";
                    document.getElementById("phone").value = "";
                    if (responseJson.message) {
                        alert(responseJson.message);
                    }
                }
            }
        }
    };
    xhttp.open("GET", "http://localhost:8083/passenger?aadharNo="
        + adharNo, true);
    xhttp.send();
}

function fetchCriminalRecords() {
    var adharNo = document.getElementById("aadharNumber").value;
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function () {
        console.log(this.response);
        console.log(this);
        if (this.readyState == 4 && this.status == 200) {
            var responseJson = JSON.parse(this.response);
            if (responseJson && responseJson.status
                && responseJson.status == "Success") {
                var table = "<table><tr><th>Case Number</th><th>Case Description</th></tr>";
                if (responseJson.criminalRecords) {
                    for (var i = 0; i < responseJson.criminalRecords.length; i++) {
                        var record = responseJson.criminalRecords[i];
                        table = table + "<tr><td>" + record.caseno + "</td><td>" + record.complaint + "</td></tr>";
                    }
                    table = table + "</table>";
                } else {
                    table = "No records found.";
                }
                document.getElementById('criminalRecord').innerHTML = table;
            } else {
                if (responseJson && responseJson.status
                    && responseJson.status == "Failure") {

                }
            }
        }
    };
    xhttp.open("GET", "http://localhost:8083/criminalRecord?aadharNo="
        + adharNo, true);
    xhttp.send();
}